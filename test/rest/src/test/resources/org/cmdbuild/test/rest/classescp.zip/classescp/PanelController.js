Ext.define('CMDBuildUI.view.custompages.classescp.PanelController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.custompages-classescp-panel',
    
    control: {
        '#comboclass': {
            change: 'onComboClassChange'
        }
    },

    /**
     * @param {Ext.form.field.ComboBox} combo
     * @param {String} newValue
     * @param {String} oldValue
     * @param {Object} eOpts
     */
    onComboClassChange: function(combo, newValue, oldValue, eOpts) {
        var view = this.getView();
        view.removeAll(true);

        if (newValue) {
            CMDBuildUI.util.helper.ModelHelper.getModel(
                'class', 
                newValue
            ).then(function(model) {
                var columns = CMDBuildUI.util.helper.GridHelper.getColumns(model.getFields());
                view.add({
                    xtype: 'grid',
                    forceFit: true,
                    scrollable: true,
                    columns: columns,
                    store: {
                        type: 'cards',
                        model: model.getName(),
                        autoLoad: true
                    },
                    listeners: {
                        selectionchange: 'onGridSelectionChange'
                    }
                });
            });
        }
    },

    /**
     * Grid selection changed.
     * 
     * @param {Ext.grid.Panel} grid
     * @param {CMDBuildUI.model.Card[]} cards
     * @param {Object} eOpts
     */
    onGridSelectionChange: function(grid, cards, eOpts) {
        if (cards.length) {
            var card = cards[0];
            // var popup = CMDBuildUI.util.Utilities.openPopup(null, card.get("Description"), {
            //     xtype: 'classes-cards-card-view',
            //     objectTypeName: card.get("_type"),
            //     objectId: card.getId(), // card.get("_id")
            //     shownInPopup: true,
            //     hideTools: true
            // });

            var popup =  CMDBuildUI.util.Utilities.openPopup(null, card.get("Description"), {
                xtype: 'custompages-classescp-form',
                viewModel: {
                    data: {
                        objectTypeName: card.get("_type"),
                        objectId: card.getId()
                    }
                }
            });
        }
    }
});
