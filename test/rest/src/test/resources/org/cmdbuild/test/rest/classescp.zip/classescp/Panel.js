
Ext.define('CMDBuildUI.view.custompages.classescp.Panel',{
    extend: 'Ext.panel.Panel',

    requires: [
        'CMDBuildUI.view.custompages.classescp.PanelController',
        'CMDBuildUI.view.custompages.classescp.PanelModel',
        'CMDBuildUI.view.custompages.classescp.Form'
    ],

    mixins: [
        'CMDBuildUI.mixins.CustomPage'
    ],

    alias: 'widget.custompages-classescp-panel',
    controller: 'custompages-classescp-panel',
    viewModel: {
        type: 'custompages-classescp-panel'
    },

    title: 'Classes - Custom Page',

    layout: 'fit',

    tbar: [{
        xtype: 'combo',
        fieldLabel: 'Class',
        displayField: 'description',
        valueField: 'name',
        itemId: 'comboclass',
        reference: 'comboclass',
        editable: false,
        // forceSelection: true,
        width: 500,
        bind: {
            store: '{classes}',
            value: '{selectedClass}'
        }
    }]
});
