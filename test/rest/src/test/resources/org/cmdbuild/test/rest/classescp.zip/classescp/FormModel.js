Ext.define('CMDBuildUI.view.custompages.classescp.FormModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.custompages-classescp-form',

    data: {
        objectTypeName: null,
        objectId: null
    }

});
