Ext.define('CMDBuildUI.view.custompages.classescp.PanelModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.custompages-classescp-panel',

    data: {
        selectedClass: null
    },

    stores: {
        classes: {
            type: 'classes',
            autoLoad: true
        }
    }

});
