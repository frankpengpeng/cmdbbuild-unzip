Ext.define('CMDBuildUI.view.custompages.classescp.FormController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.custompages-classescp-form',

    control: {
        '#': {
            afterrender: 'onBeforeRender'
        }
    },

    /**
     * @param {CMDBuildUI.view.custompages.classescp.Form} view
     * @param {Object} eOpts
     */
    onBeforeRender: function(view, eOpts) {
        var vm = this.getViewModel();
        CMDBuildUI.util.helper.ModelHelper.getModel(
            CMDBuildUI.util.helper.ModelHelper.objecttypes.klass, // 'class'
            vm.get("objectTypeName")
        ).then(function(model) {
            vm.linkTo("theObject", {
                type: model.getName(),
                id: vm.get("objectId")
            });
            var items = CMDBuildUI.util.helper.FormHelper.renderForm(model, {
                readonly: true,
                showAsFieldsets: true
            });
            view.add(items);
        });
    }
    
});
