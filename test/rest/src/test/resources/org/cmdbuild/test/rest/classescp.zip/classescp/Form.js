
Ext.define('CMDBuildUI.view.custompages.classescp.Form',{
    extend: 'Ext.form.Panel',

    requires: [
        'CMDBuildUI.view.custompages.classescp.FormController',
        'CMDBuildUI.view.custompages.classescp.FormModel'
    ],

    alias: 'widget.custompages-classescp-form',
    controller: 'custompages-classescp-form',
    viewModel: {
        type: 'custompages-classescp-form'
    },

    config: {
        /**
         * @cfg {String}
         * Object type name.....
         */
        objectTypeName: null,

        /**
         * @cfg {Integer}
         * Object type name.....
         */
        objectId: null
    },

    publishes: [
        'objectTypeName',
        'objectId'
    ],

    bind: {
        objectTypeName: '{objectTypeName}',
        objectId: '{objectId}'
    },

    fieldDefaults: {
        labelAlign: 'top'
    },

    /**
     * @param {String} newValue
     * @param {String} oldValue
     */
    updateObjectTypeName: function(newValue, oldValue) {
        console.log("updateObjectTypeName", newValue, oldValue);
    },

    /**
     * @param {String} newValue
     * @param {String} oldValue
     */
    updateObjectId: function(newValue, oldValue) {
        console.log("updateObjectId", newValue, oldValue);
    }
});
