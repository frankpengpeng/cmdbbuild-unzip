Ext.define('CMDBuildUI.view.contextmenucomponents.firstcomponent.FirstComponentModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.contextmenucomponents-firstcomponent-firstcomponent',
    data: {
        name: 'CMDBuildUI'
    }

});
