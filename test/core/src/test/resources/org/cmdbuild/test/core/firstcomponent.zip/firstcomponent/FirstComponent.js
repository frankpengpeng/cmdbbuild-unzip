
Ext.define('CMDBuildUI.view.contextmenucomponents.firstcomponent.FirstComponent',{
    extend: 'Ext.panel.Panel',

    requires: [
        'CMDBuildUI.mixins.ContextMenuComponent',
        'CMDBuildUI.view.contextmenucomponents.firstcomponent.FirstComponentController',
        'CMDBuildUI.view.contextmenucomponents.firstcomponent.FirstComponentModel'
    ],

    mixins: [
        'CMDBuildUI.mixins.ContextMenuComponent'
    ],

    alias: 'widget.contextmenucomponents-firstcomponent-firstcomponent',
    controller: 'contextmenucomponents-firstcomponent-firstcomponent',
    viewModel: {
        type: 'contextmenucomponents-firstcomponent-firstcomponent'
    },

    html: 'Hello, World!!'
});
