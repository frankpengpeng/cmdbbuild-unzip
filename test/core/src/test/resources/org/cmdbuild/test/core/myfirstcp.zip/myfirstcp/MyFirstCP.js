
Ext.define('CMDBuildUI.view.custompages.myfirstcp.MyFirstCP', {
    extend: 'Ext.panel.Panel',

    requires: [
        'CMDBuildUI.view.custompages.myfirstcp.MyFirstCPController',
        'CMDBuildUI.view.custompages.myfirstcp.MyFirstCPModel',
        'CMDBuildUI.mixins.CustomPage'
    ],

    mixins: [
        'CMDBuildUI.mixins.CustomPage'
    ],

    alias: 'widget.custompages-myfirstcp',
    controller: 'custompages-myfirstcp',
    viewModel: {
        type: 'custompages-myfirstcp'
    },

    scrollable: true,

    bind: {
        title: 'Elenco delle classi ({classes.totalCount})',
    },

    items: [{
        xtype: 'grid',
        forceFit: true,
        scrollable: true,
        itemId: 'classesgrid',
        reference: 'classesgrid',
        bind: {
            store: '{classes}'
        },
        columns: [{
            text: 'Name',
            dataIndex: 'name',
            hideable: false
        },
        {
            text: 'Description',
            dataIndex: 'description'
        },
        {
            text: 'parent',
            dataIndex: 'parent'
        },
        {
            text: 'prototype',
            dataIndex: 'prototype'
        },
        {
            text: 'type',
            dataIndex: 'type'
        },
        {
            text: 'system',
            dataIndex: 'system'
        },
        {
            text: 'attachmentTypeLookup',
            dataIndex: 'attachmentTypeLookup'
        },
        {
            text: 'attachmentMode',
            dataIndex: 'attachmentMode'
        },
        {
            text: 'active',
            dataIndex: 'active'
        }]
    }],

    tbar: [{
        xtype: 'button',
        text: 'Disable superclasses',
        ui: 'management-action',
        iconCls: 'x-fa fa-minus-square-o',
        itemId: 'disableprototypebtn',
        reference: 'disableprototypebtn',
        enableToggle: true,
        bind: {
            pressed: '{button.pressed}',
            text: '{button.actiontext} superclasses',
            iconCls: 'x-fa {button.iconcls}'
        }
    }]
});
