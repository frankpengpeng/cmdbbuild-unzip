Ext.define('CMDBuildUI.view.custompages.myfirstcp.MyFirstCPController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.custompages-myfirstcp',

    control: {
        '#': {

        },
        '#classesgrid': {
            selectionchange: 'onClassesGridSelectionChange'
        },
        '#disableprototypebtn': {
            toggle: 'onDisablePrototypeBtnToggle'
        }
    },

    onClassesStoreLoaded: function (store, records, success) {
        this.getView().setTitle(this.getView().getTitle() + " (" + records.length + ")")
    },

    /**
     * Handler for disable prototype button.
     * 
     * @param {Ext.button.Button} button
     * @param {Boolean} pressed
     * @param {Object} eOpts
     */
    onDisablePrototypeBtnToggle: function (button, pressed, eOpts) {
        var vm = this.getViewModel();
        var view = this.getView();

        var store = vm.get("classes");

        if (pressed) {
            store.addFilter(function (item) {
                return !item.get("prototype");
            });
        } else {
            store.clearFilter();
        }
    },

    /**
     * Called on selection change.
     * @param {Ext.grid.Panel} grid
     * @param {CMDBuildUI.model.Class[]} selected
     * @param {Object} eOpts
     */
    onClassesGridSelectionChange: function (grid, selected, eOpts) {
        if (selected.length) {
            var popup = CMDBuildUI.util.Utilities.openPopup(null, 'Popup title', {
                xtype: 'form',

                fieldDefaults: {
                    labelAlign: 'top'
                },

                layout: 'hbox',

                defaults: {
                    xtype: 'fieldcontainer',
                    flex: 0.5
                },

                items: [{
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'Name',
                        bind: {
                            value: '{theClass.name}'
                        }
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'Description',
                        bind: {
                            value: '{theClass.description}'
                        }
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'parent',
                        bind: {
                            value: '{theClass.parent}'
                        }
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'prototype',
                        bind: {
                            value: '{theClass.prototype}'
                        }
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'type',
                        bind: {
                            value: '{theClass.type}'
                        }
                    }]
                }, {
                    items: [{
                        xtype: 'displayfield',
                        fieldLabel: 'system',
                        bind: {
                            value: '{theClass.system}'
                        }
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'attachmentTypeLookup',
                        bind: {
                            value: '{theClass.attachmentTypeLookup}'
                        }
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'attachmentMode',
                        bind: {
                            value: '{theClass.attachmentMode}'
                        }
                    }, {
                        xtype: 'displayfield',
                        fieldLabel: 'active',
                        bind: {
                            value: '{theClass.active}'
                        }
                    }]
                }],

                viewModel: {
                    data: {
                        theClass: selected[0]
                    }
                },

                buttons: [{
                    text: CMDBuildUI.locales.Locales.common.actions.close,
                    ui: 'secondary-action',
                    iconCls: 'x-fa fa-times',
                    handler: function() {
                        popup.close();
                    }
                }],
            });
        }
    }

});
