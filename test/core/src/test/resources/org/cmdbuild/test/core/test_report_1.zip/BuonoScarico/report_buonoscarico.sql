DROP FUNCTION IF EXISTS report_buonoscarico(bigint);

CREATE OR REPLACE FUNCTION report_buonoscarico(IN mov_id BIGINT, 
    OUT nome_zona_tlc VARCHAR,
    OUT codice_ucb_zona_tlc TEXT,
    OUT citta_zona_tlc VARCHAR,
    OUT identificativo_buono TEXT,
    OUT causale TEXT,
    OUT ufficio TEXT,
    OUT ordine VARCHAR,
    OUT data_ordine TEXT,
    OUT ministeriale VARCHAR,
    OUT data_ministeriale TEXT,
    OUT protocollo VARCHAR,
    OUT data_protocollo TEXT,
    OUT dettagli TEXT,
    OUT consegnatario TEXT,
    OUT direttore TEXT,
    OUT um_nuc VARCHAR,
    OUT conto_nuc VARCHAR,
    OUT cod_nuc VARCHAR,
    OUT nome_nuc VARCHAR,
    OUT prezzo_nuc NUMERIC,
    OUT quantita INTEGER,
    OUT importo NUMERIC
    )
RETURNS SETOF RECORD AS
$$
DECLARE
    zona_tlc_id INTEGER = (SELECT "Id" FROM "Office" WHERE "REMACode" = 'ZTPD' AND "Status" = 'A');
BEGIN

    RETURN QUERY
    SELECT 
        (SELECT "Name" FROM "Office" WHERE "REMACode" = 'ZTPD' AND "Status" = 'A') AS nome_zona_tlc,
        concat_ws(' ', 'CODICE CONSEGNATARIO', (SELECT "UCBCode" FROM "Office" WHERE "Id" = (SELECT "Id" FROM "Office" WHERE "REMACode" = 'ZTPD' AND "Status" = 'A'))) AS codice_ucb_zona_tlc,
        (SELECT "City" FROM "Office" WHERE "Id" = (SELECT "Id" FROM "Office" WHERE "REMACode" = 'ZTPD' AND "Status" = 'A')) AS citta_zona_tlc,
        concat_ws(' ', 'Buono di scarico', mov."Number", 'del', to_char(mov."Date", 'DD/MM/YYYY')) AS identificativo_buono,
        CASE WHEN (SELECT "Code" FROM "LookUp" WHERE "Id" = mov."Type" ) <> '?' THEN concat_ws(' ', 'Causale', (SELECT "Description" FROM "LookUp" WHERE "Id" = mov."Type")) ELSE NULL END AS causale,
        concat_ws(' ', 'Prelevato da', 
            (SELECT "Description" FROM "Office" WHERE "Id" = mov."Receiver"), 
            (CASE WHEN (SELECT "Code" FROM "LookUp" WHERE "Id" = mov."Type") IN ('S2', 'S3') THEN (SELECT "UCBCode" FROM "Office" WHERE "Id" = mov."Receiver") ELSE NULL END)
        ) AS ufficio,
        CASE WHEN nullif("OrderNum", '') IS NOT NULL THEN "OrderNum" ELSE NULL END AS ordine,
        CASE WHEN nullif("OrderNum", '') IS NOT NULL THEN to_char("OrderDate", 'DD/MM/YYYY') ELSE NULL END AS data_ordine,
        CASE WHEN nullif("MinistNum", '') IS NOT NULL THEN "MinistNum" ELSE NULL END AS ministeriale,
        CASE WHEN nullif("MinistNum", '') IS NOT NULL THEN to_char("MinistDate", 'DD/MM/YYYY') ELSE NULL END AS data_ministeriale,
        CASE WHEN nullif("RegisterNum", '') IS NOT NULL THEN "RegisterNum" ELSE NULL END AS protocollo,
        CASE WHEN nullif("RegisterNum", '') IS NOT NULL THEN to_char("RegisterDate", 'DD/MM/YYYY') ELSE NULL END AS data_protocollo,
        NULLIF(trim("Details"), '') AS dettagli,
        concat_ws(' ', 'Il Consegnatario', (SELECT "FirstName" FROM "Employee" WHERE "Id" = (SELECT "Consignee" FROM "Office" WHERE "Id" = (SELECT "Id" FROM "Office" WHERE "REMACode" = 'ZTPD' AND "Status" = 'A'))), 
                    (SELECT "LastName" FROM "Employee" WHERE "Id" = (SELECT "Consignee" FROM "Office" WHERE "Id" = (SELECT "Id" FROM "Office" WHERE "REMACode" = 'ZTPD' AND "Status" = 'A')))) AS consegnatario,
        concat_ws(' ', 'Il Direttore', (SELECT "FirstName" FROM "Employee" WHERE "Id" = (SELECT "Director" FROM "Office" WHERE "Id" = (SELECT "Id" FROM "Office" WHERE "REMACode" = 'ZTPD' AND "Status" = 'A'))), 
                    (SELECT "LastName" FROM "Employee" WHERE "Id" = (SELECT "Director" FROM "Office" WHERE "Id" = (SELECT "Id" FROM "Office" WHERE "REMACode" = 'ZTPD' AND "Status" = 'A')))) AS direttore,
        (SELECT "Description" FROM "LookUp" WHERE "Id" = (SELECT "UM" FROM "NUC" WHERE "Id" = riga."NUC")) AS um_nuc,
        (SELECT "Code" FROM "Account" WHERE "Id" = (SELECT "Account" FROM "NUC" WHERE "Id" = riga."NUC")) AS conto_nuc,
        (SELECT "Code" FROM "NUC" WHERE "Id" = riga."NUC")  AS cod_nuc,
        (SELECT "Name" FROM "NUC" WHERE "Id" = riga."NUC")  AS nome_nuc,
        (SELECT "InventoryPrice" FROM "NUC" WHERE "Id" = riga."NUC")  AS prezzo_nuc,
        riga."Quantity"  AS quantita,
        riga."Amount" AS importo        
    FROM "WarehouseUnload" AS mov
    LEFT JOIN "WarehouseUnloadRow" AS riga ON riga."WrhMovement" = mov."Id" AND riga."Status" = 'A'
    WHERE mov."Status" = 'A' 
    AND mov."Id" = mov_id;
END;
$$
LANGUAGE plpgsql VOLATILE;


/**
SELECT * FROM report_buonoscarico((SELECT "Id" FROM "WarehouseUnload" WHERE "Status" = 'A' AND "Year" = '2018' LIMIT 1));
SELECT * FROM report_buonoscarico((SELECT "Id" FROM "WarehouseUnload" WHERE "Status" = 'A' AND "Description" = 'S FU 2015 004' LIMIT 1));
**/
