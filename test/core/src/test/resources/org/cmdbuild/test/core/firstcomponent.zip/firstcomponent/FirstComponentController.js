Ext.define('CMDBuildUI.view.contextmenucomponents.firstcomponent.FirstComponentController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.contextmenucomponents-firstcomponent-firstcomponent'
    
});
