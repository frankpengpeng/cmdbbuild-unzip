Ext.define('CMDBuildUI.view.custompages.myfirstcp.MyFirstCPModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.custompages-myfirstcp',

    data: {
        button: {
            pressed: false,
            actiontext: 'Disable',
            iconcls: 'fa-minus-square-o'
        }
    },

    links: {
        // theObject: {
        //     model: ''
        // }
    },

    formulas: {
        /**
         * Update button properties
         */
        updateButtonProperties: {
            bind: {
                pressed: '{button.pressed}'
            },
            get: function(data) {
                if (data.pressed) {
                    this.set("button.actiontext", "Enable");
                    this.set("button.iconcls", "fa-plus-square-o");
                } else {
                    this.set("button.actiontext", "Disable");
                    this.set("button.iconcls", "fa-minus-square-o");
                }
            }
        }

        // buttonText: {
        //     bind: '{button.pressed}',
        //     get: function(pressed) {
        //         return pressed ? 'Enable' : 'Disable';
        //     }
        // },

        // buttonIconCls: {
        //     bind: '{button.pressed}',
        //     get: function(pressed) {
        //         return pressed ? "fa-plus-square-o" : "fa-minus-square-o";
        //     }
        // }
    },

    stores: {
        classes: {
            type: 'classes',
            autoLoad: true,
            // listeners: {
            //     load: 'onClassesStoreLoaded'
            // }
        }
    }

});
